Chatrapati GFX website

Open index.html in a browser.
Later, replace the placeholder work cards with your Social Media / My Work images.
Also update the WhatsApp and Instagram links in index.html.
